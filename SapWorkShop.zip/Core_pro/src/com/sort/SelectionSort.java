package com.sort;

public class SelectionSort {

	public static void main(String[] args) {
		//int[] arr = {3,1,10,4,7,0};
		
		int[] arr1 = {10,34,2,56,7,67,88,42};
		
		int arr2 [] = performSelectionSort(arr1);
		for(int m=0;m<arr2.length;m++) {
			System.out.println(arr2[m]);
		}

	}
	
	public static int [] performSelectionSort(int[] arr) {
		
		for(int i = 0; i < arr.length-1; i++) {
			for(int j = i+1; j < arr.length; j++) {//{3,1,10,4,7,0};
				if(arr[j] < arr[i]) {
					int temp = arr[j];
					arr[j] = arr[i];
					arr[i] = temp;
				}
			}
		}
		return arr;
	}
	
	/*public static void swapNumber(int i,int index,int[] arr) {
		int temp = arr[index];
		arr[index] = arr[i];
		arr[i] = temp;
	}*/

}
