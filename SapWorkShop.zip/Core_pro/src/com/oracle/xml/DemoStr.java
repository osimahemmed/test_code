package com.oracle.xml;

public class DemoStr {

	  public static void main(String args[]) {
		  /*
		  String s = "puiblic";
		  System.out.println(s);
		  System.out.println("lastIndexOf(u, 4) = " + s.lastIndexOf("ic", 5));
*/
		 
			    System.out.println("Hello".hashCode());
			    System.out.println("Hello".hashCode());
			  
	  }
}