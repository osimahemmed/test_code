/*package com.oracle.xml;

import java.util.Comparator;

public class UserNameComparator implements Comparator { 
	
    public int compare(Object user, Object anotherUser) { 
    
    String firstName1 = ((User) user).getUserName().toUpperCase(); 
    System.out.println("first Name1 is " + firstName1);
    
    String firstName2 = ((User) anotherUser).getUserName().toUpperCase();
    
    System.out.println("first Name2 is " + firstName2);
    
    return firstName1.compareTo(firstName2); 
    
    } 
   } 

*/