package com.sape.marker;

public interface MarkerFoo {

}
