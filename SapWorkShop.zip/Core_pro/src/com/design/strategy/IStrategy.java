package com.design.strategy;

public interface IStrategy {

	public int doOperation(int num1, int num2);
	
}
