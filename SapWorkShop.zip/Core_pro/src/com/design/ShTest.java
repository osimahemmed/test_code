package com.design;

public class ShTest {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		
		long a = 1234;
		long b = 1235;
		
		int c = (int) (b-a);
		
		System.out.println("result" + c);

	}

}
