package com.design;

public class Male extends Person{
	public Male(String fullName){
		System.out.println("Hello Mr."+fullName);
	}
}
