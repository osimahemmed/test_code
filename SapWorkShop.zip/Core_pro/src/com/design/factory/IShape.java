package com.design.factory;

public interface IShape {
	void draw();
}
