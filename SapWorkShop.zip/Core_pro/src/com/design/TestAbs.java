package com.design;

public abstract class TestAbs {
	
	final void sayHello() {
		
		System.out.println("hello in final method");
	}
	
	abstract void method1();

}
