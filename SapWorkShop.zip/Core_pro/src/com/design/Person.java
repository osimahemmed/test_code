package com.design;

public class Person {
	public String name;
	private String gender;
	public String getName() {
		return name;
	}
	public String getGender() {
		return gender;
	}
}