package com.custom.blocking.queue;

public interface CustomBlockingQueue<E> {
	void put(E item) throws InterruptedException;
	E take() throws InterruptedException;
}
