package com.custom.clas.loader;

public class IntegerPrinter {
    /**
     * Creates an instance of Integer class and prints it.
     */
    public void runMe() {
        System.out.println(new Integer(4));
    }
}
