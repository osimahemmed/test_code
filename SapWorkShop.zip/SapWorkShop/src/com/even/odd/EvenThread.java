package com.even.odd;

public class EvenThread implements Runnable {
	
	Object mutex;
	public EvenThread(Object mutex) {
		this.mutex = mutex;
	}

	@Override
	public void run() {
		for(int i=0;i<=10;i=i+2) {
			synchronized (mutex) {
				while(EvenOdd.printFlag) {
					try {
						mutex.wait(10);
					} catch (InterruptedException e) {
						e.printStackTrace();
					}
				}
				System.out.println(i);
				EvenOdd.printFlag = !EvenOdd.printFlag;
				//mutex.notifyAll();
			}
		}
		
	}

}
