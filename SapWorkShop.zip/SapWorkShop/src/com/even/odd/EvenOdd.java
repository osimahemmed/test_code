package com.even.odd;

public class EvenOdd {

	static boolean printFlag = false;
	public static void main(String[] args) {
		
		Object mutex = new Object();
		
		Thread even = new Thread(new EvenThread(mutex));
		Thread odd = new Thread(new OddThread(mutex));
		even.start();
		odd.start();

	}

}
