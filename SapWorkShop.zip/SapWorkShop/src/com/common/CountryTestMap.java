package com.common;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class CountryTestMap {

	public static void main(String[] args) {
		
		List<Country> countryList = new ArrayList<Country>(); 
		
		Country country1 = new Country("India", "Mumbai", 10);
		Country country2 = new Country("India", "Chennai", 20);
		Country country3 = new Country("India", "Bangalore", 10);
		Country country4 = new Country("UK", "London", 50);
		Country country5 = new Country("UK", "London", 50);
		
		countryList.add(country1);
		countryList.add(country2);
		countryList.add(country3);
		countryList.add(country4);
		countryList.add(country5);
		
		Map<String, Integer> map = new HashMap<String, Integer>();
		
		System.out.println(countryList.size());
		for(Country country : countryList) {
			String countryName = country.getCountry();
			String cityName = country.getCity();
			if(map.containsKey(countryName+cityName)) {
				map.put(countryName+cityName, map.get(countryName+cityName)+1);
			} else {
				map.put(countryName+cityName, 1);
			}
		//	System.out.println(country.getCountry());
		}
		System.out.println(map);

	}

}
