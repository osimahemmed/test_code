package com.common;

import java.io.IOException;

public class TestException {

	public static void main(String[] args) {
		
		int a = 0;
		int b = 1;
		try {
			int c = b/a;
		} catch (Exception e) {
			
		} 

	}

}
