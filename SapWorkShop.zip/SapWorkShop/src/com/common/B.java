package com.common;

public class B extends A  {
	private int a = 10;
	public static void sayHello() {
		System.out.println("Sublass B");
	}
	
	public static void main(String[] args) {
		A b = new B();
		b.sayHello();
		System.out.println(b.a);
	}
}
