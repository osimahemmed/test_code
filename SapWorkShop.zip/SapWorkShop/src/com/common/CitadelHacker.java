package com.common;

import java.util.LinkedList;
import java.util.Queue;

public class CitadelHacker {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		Integer num = 15;
		Integer count = getCount(num) ;
		System.out.println(count);
	}
	
	private static int getCount(Integer num) {
		
		Queue<Integer> queue = new LinkedList<>();
		
		int j=1;
		int sum = 0;
		int count = 0;
		queue.add(j);
		sum = j;
		while(j<=((num+1)/2)) {
			if(sum == num){
				count++;
				j++;
				System.out.println(queue.toString());
				queue.add(j);
				sum = sum + j;
			}else if(sum < num){
				j++;
				queue.add(j);
				sum = sum + j;
			}else {
				sum = sum - queue.poll();
			}
		}
		System.out.println("count = " + count);
		return count;
	}
}

