package com.common;

public interface TestAJava8Interface {
	
	public static void sayHi() {
		System.out.println(" Hi ");
	}

}
