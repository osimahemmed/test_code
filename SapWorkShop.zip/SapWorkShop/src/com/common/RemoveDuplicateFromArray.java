package com.common;

import java.util.Arrays;

public class RemoveDuplicateFromArray {

	public static void main(String[] args) {
		int[] input = new int[] { 10,70,30,90,20,20,30,40,70,50};
		int[] arr = {1,1,4,4,5,7,8,9,9,10};
		removeDup(arr);
		
		/*Arrays.sort(input);
		int length = input.length;
		
		length = removeDuplicates(input, length);
		for(int i = 0; i < length; i++) {
			System.out.println(input[i] + " ");
		}*/
		/*Arrays.sort(input);
		int length = input.length;
		length = removeDuplicates(input,length );
		for(int i = 0; i < length; i++) {
			System.out.println(input[i] + " ");
		}*/
		
		//System.out.println(input.length);

	}
	
	private static int removeDupsFromArray(int[] arr, int n) {
		if(n == 0 || n == 1) {
			return n;
		}
		
		int[] temp = new int[n];
		int j = 0;
		
		for(int i = 0; i< n-1; i++) {
			if(arr[i] != arr[i+1]) {
				temp[j++] = arr[i];
			}
		}
		temp[j++] = arr[n-1];
		
		for(int i = 0; i < j; i++) {
			arr[i] = temp[i];
		}
		return j;
	}
	
	
	public static int removeDuplicates(int[] arr, int n) {
		// Return, if array is empty
        // or contains a single element
		if(n == 0 || n == 1) {
			return n;
		}
		
		int[] temp = new int[n]; 
		int j = 0;
		for(int i = 0; i < n-1; i++) {
			// If current element is not equal
            // to next element then store that
            // current element
			if(arr[i] != arr[i+1]) {
				
				/*if(arr[i] == arr[i+1]) { // for printing duplicates
					System.out.println("dups are " + arr[i]);*/
				
				temp[j++] = arr[i];
			
			}
		}
		
		 // Store the last element as whether
        // it is unique or repeated, it hasn't
        // stored previously
		temp[j++] = arr[n-1];
		
		// Modify original array
		for(int i = 0; i < j; i++) {
			arr[i] = temp[i];
		}
		
		return j;
	}
	
	private static int removeDup(int[] arr) {
	
		Arrays.sort(arr);
		int n = arr.length;
		int[] temp = new int[n];
		
		int j = 0;
		
		for(int i = 0; i < arr.length-1; i++) {
			if(arr[i] != arr[i+1]) {//1,1,4,4,5,7,8,9,9,10
				temp[j++] = arr[i];
			}
		}
		
		temp[j++] = arr[n-1];
		for(int i = 0; i < j; i++) {
			arr[i] = temp[i];
		}
		
		return j;
	}

}
