package com.common;

public class MovingZerostoRight {

	public static void main(String[] args) {

		//int[] A = {1,9,8,4,0,0,2,7,0,6,0};// move zeros to right
		int[] A = {-1,9,8,-4,-10,3,2,7,-2,11,-5,0};
		MovingZerostoRight move = new MovingZerostoRight();
		move.moveZerosToEnd(A);
		for(int i : A){
			System.out.println(i);
		}

	}
	
	public void moveZerosToEnd(int[] A) {
		int i,j;
		for(i=0,j=0;i<A.length;i++) {
			if(A[i] >= 0) {//moving negative number to right
			//if(A[i] != 0) {//moving zeros to right
				mySwap(A,j++,i);
			}
		}
	}
	
	public void mySwap(int[] A, int j, int i) {
		int temp = A[i];
		A[i] = A[j];
		A[j] = temp;
	}

}
