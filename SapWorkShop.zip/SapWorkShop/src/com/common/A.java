package com.common;

public class A {
	public int a = 5;
	public static void sayHello() {
		System.out.println("Super class A");
	}

}