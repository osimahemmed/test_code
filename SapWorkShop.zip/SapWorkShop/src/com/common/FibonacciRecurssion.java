package com.common;

public class FibonacciRecurssion {

	public static void main(String[] args) {
		
		int n = 10;
		System.out.println("0");
		System.out.println("1");
		for(int i = 2; i <= n; i++) {
			System.out.println(fiboRecurssion(i));
		}
	}
	
	private static int fiboRecurssion(int num) {
		if(num == 1 || num == 2) {
			return 1;
		} 
		
		return fiboRecurssion(num-1)+ fiboRecurssion(num-2);
	}

}
