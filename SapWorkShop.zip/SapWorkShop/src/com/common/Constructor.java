package com.common;

import java.util.PriorityQueue;
import java.util.Queue;

public class Constructor {
	static String str;
	
	public void Constructor() {
		System.out.println("In constuctor");
		str = "hello";
	}
	
	public static void main(String[] args) {
		int count = 0;
		Constructor c = new Constructor(); 
		System.out.println(str);
		
		PriorityQueue<Integer> pQueue = new PriorityQueue<>(3);
		
		pQueue.add(500);
		pQueue.add(100);
		pQueue.add(10);
		pQueue.add(50);
		pQueue.add(2);
		while(!pQueue.isEmpty()) {
			count ++;
			System.out.println(pQueue.remove());
		}
	}

}
