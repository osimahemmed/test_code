package com.common;

import java.util.Scanner;

public class JavaStringReverse {

	public static boolean isPalindrome(String word)
	{
		boolean isPalindrome = true;
		for(int i = 0; i < word.length()/2; i++) {
			if(word.charAt(i) != word.charAt(word.length()-1-i)) {
				isPalindrome = false;
			}
		}
		
		return isPalindrome;
	}
	public static void main(String[] args) {

		Scanner sc=new Scanner(System.in);
		String A=sc.next();  
		System.out.println(isPalindrome(A)?"Yes":"No");

	}

}
