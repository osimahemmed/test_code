package com.common;

import java.util.LinkedHashSet;
import java.util.Set;
import java.util.SortedSet;
import java.util.TreeSet;

public class TreeSetTest {

	public static void main(String[] args) {
		
		User u1 = new User(12, "A");
		User u2 = new User(2, "B");
		User u3 = new User(0, "D");
		
		@SuppressWarnings("rawtypes")
		TreeSet set = new TreeSet();
		SortedSet sortedNames = new TreeSet();
		
		Set lnSet = new LinkedHashSet();
		lnSet.add(u1);
		lnSet.add(u2);
		lnSet.add(u3);
		//sortedNames.add(u1);
		//set.add(u1);
		System.out.println(lnSet);
		
		
		/*set.add(5);
		set.add("ABC");*/
		
		System.out.println(set);

	}
	
	static class User {
		private int age;
		private String name;
		public User(int age, String name) {
			this.age = age;
			this.name = name;
		}
		
		@Override
		public String toString() {
			return "User["+" age " + age + " name " + name +"]";
		}
	}

}
