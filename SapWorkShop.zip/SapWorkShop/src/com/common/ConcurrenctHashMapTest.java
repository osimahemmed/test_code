package com.common;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

public class ConcurrenctHashMapTest {

	public static void main(String[] args) {
		
		List list = new ArrayList();
		list.add(1);
		list.add("str");
		list.add(0.6f);
		
		Integer s = (Integer)list.get(0);
		System.out.println("S = " +s);
		
		System.out.println(list);
		
		Map<Integer, Integer> map = new ConcurrentHashMap<Integer,Integer>(16, (float) 0.75, 16);
		map.put(1, 10);
		map.put(2, 20);
		map.put(3, 30);
		
		System.out.println(map);

	}

}
