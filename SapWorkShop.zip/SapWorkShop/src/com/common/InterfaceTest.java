package com.common;

public interface InterfaceTest {

	public static String sayHello() {
		return "Hello India";
	}
}
