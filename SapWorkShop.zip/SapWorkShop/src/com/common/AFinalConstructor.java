package com.common;

public class AFinalConstructor {
	public AFinalConstructor() {
		System.out.println("hello super class");
	}

}
