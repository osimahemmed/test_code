package com.common;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;

public class CloneTest {

	public static void main(String[] args) {
		
		Set<Employee> set = new TreeSet<>();
		List<Employee> list = new ArrayList<Employee>();
		Employee emp1 = new Employee("A");
		Employee emp2 = new Employee("B");
		Employee emp3 = new Employee("C");
		set.add(emp1);
		set.add(emp2);
		set.add(emp3);
		
		System.out.println(set);
		
		list.add(emp1);
		list.add(emp2);
		list.add(emp3);
		
		System.out.println(list.size());
		
		@SuppressWarnings("unchecked")
		List<Employee> list2 = ((List<Employee>) ((ArrayList<Employee>) list).clone());
		
		System.out.println(" osim "+list2.size() );

	}

}
