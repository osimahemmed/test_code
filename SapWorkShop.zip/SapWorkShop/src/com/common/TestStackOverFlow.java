package com.common;

public class TestStackOverFlow {
	
	 public TestStackOverFlow() {
		System.out.println("overflow");
	}
	 
	TestStackOverFlow t1 = new TestStackOverFlow();

	public static void main(String[] args) {
		TestStackOverFlow t = new TestStackOverFlow();
		
	}

}
