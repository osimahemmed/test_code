package com.common;

import java.util.Scanner;

public class ReverseDecimal {
	
	public static void main(String[] args)
    {                       
        double d = 0, 
        Result = 0;

        Scanner in = new Scanner(System.in); 

        System.out.print("enter a number: ");

        d = in.nextDouble(); 

        while(d > 0)
        { 
            Result = (Result * 10) + d % 10; 
            d = d / 10;
        } 

        System.out.println("\nThe Reversed Number Is: " + Result);          

    }

}
