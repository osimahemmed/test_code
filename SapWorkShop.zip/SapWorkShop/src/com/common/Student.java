package com.common;

public class Student {
	private String name;
	private int age;
	private int totalMarks;
	
	public Student() {
		
	}
	
	public Student(String name,int age, int marks) {
		this.name = name;
		this.age = age;
		this.totalMarks = marks;
	}
	
	public void setMarks(int marks) {
		this.totalMarks = marks;
	}
	@Override
	public int hashCode() {
		return 1;
	}
	@Override
	public boolean equals(Object obj) {
		if(this == obj) {
			return true;
		}
		if((obj == null)) {
			
		}
		return false;
	}
	
	

}
