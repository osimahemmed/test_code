package com.common;

public class SumOfConsecutiveNumber {

	public static void main(String[] args) {
		long Num = 15;
		int a = getConsecutiveCount(Num);
		System.out.println("consecutive " + a);
	}
	public static int getConsecutiveCount(long N)
	{
	    int start = 1, end = 1;
	    int sum = 1;
	    int count  = 0;
	 
	    while (start <= N/2)
	    {
	        if (sum < N)
	        {
	            end += 1;
	            sum += end;
	        }
	        else if (sum > N)
	        {
	            sum -= start;
	            start += 1;
	        }
	        else if (sum == N)
	        {
	        	count ++;
	        	/*System.out.println("count" + count);
	            for (int i = start; i <= end; ++i)
	                System.out.println(i);
	 
	            System.out.println("\n");*/
	            sum -= start;
	            start += 1;
	        }
	    }
	    return count;
	}

}
