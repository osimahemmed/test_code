package com.common;

public class TestConstructor {

	public static void main(String[] args) {
		TestConstructor test = new TestConstructor(null);
		test = null;
		test.m1();

	}
	
	public TestConstructor(Object obj) {
		System.out.println("obj " + obj);
	}
	
	/*public TestConstructor(String str) {
		System.out.println("str " + str);
	}*/
	
	public TestConstructor(Integer int1) {
		System.out.println("int1 " + int1);
	}
	
	private void m1() {
		System.out.println("m1 called");
	}
	

}
