package com.common;

public interface ITest1 {
	void test();

}
