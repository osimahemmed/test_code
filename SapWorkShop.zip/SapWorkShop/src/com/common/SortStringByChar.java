package com.common;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class SortStringByChar {

	public static void main(String[] args) {
		List<String> list = new ArrayList<String>();
		/*list.add("abb");
		list.add("cba");
		list.add("dcb");*/
		list.add("abc");
		list.add("bca");
		list.add("avc");
		list.add("ert");
		
		Collections.sort(list, (s1, s2) -> {
			String sb1 = s1.substring(s1.length()-1);
			String sb2 = s2.substring(s2.length()-1);
			return sb1.compareTo(sb2);
		});
		
		Collections.sort(list, (s1, s2) -> {
			String sb1 = s1.substring(s1.length()-1);
			String sb2 = s2.substring(s2.length()-1);
			return sb1.compareTo(sb2);
			
		});

		System.out.println("Sorted List = " + list);
		String str[] = {"abc","bca","avc","ert"};
	   /* Arrays.sort(str, new Comparator<String>() {
	        @Override
	        public int compare(String o1, String o2) {
	           return o1.charAt(o1.length()-1) - o2.charAt(o2.length()-1) ;
	        }
	    });*/
		Arrays.sort(str, new Comparator<String>() {
			@Override
			public int compare(String o1, String o2) {
				String sb1 = o1.substring(o1.length()-1);
				String sb2 = o2.substring(o2.length()-1);
				return sb1.compareTo(sb2);
				
				//return o1.charAt(o1.length()-1) - o2.charAt(o2.length()-1);
			}
		});
	    
	    System.out.println(Arrays.toString(str));
    }
}
