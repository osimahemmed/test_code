package com.common;

import java.util.ArrayList;
import java.util.List;

public class ListRestriction {

	public static void main(String[] args) {
		//List<String> list = new ArrayList<nteger>();

	}
	
	

}
