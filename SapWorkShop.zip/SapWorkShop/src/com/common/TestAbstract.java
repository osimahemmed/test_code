package com.common;

public abstract class TestAbstract {

	public static String test() {
		return "Hello test";
	}
}
