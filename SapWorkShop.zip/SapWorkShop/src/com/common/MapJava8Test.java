package com.common;

import java.util.HashMap;
import java.util.Map;
import java.util.TreeMap;

public class MapJava8Test {

	public static void main(String[] args) {
		
		Student s = new Student("osim",12,100);
		Student s1 = new Student("osim",12,100);
		Student s2 = new Student("osim",12,100);
		Student s3 = new Student("osim",12,100);
		Student s4 = new Student("osim",12,100);
		Student s5 = new Student("osim",12,100);
		Student s6 = new Student("osim",12,100);
		Student s7 = new Student("osim",12,100);
		Student s8 = new Student("osim",12,100);
		Student s9 = new Student("osim",12,100);
		Map<Object, String> map = new HashMap<Object, String>();
		map.put(s, "1");
		map.put(s1, "2");
		map.put(s2, "3");
		map.put(s3, "4");
		map.put(s4, "5");
		map.put(s5, "6");
		map.put(s6, "7");
		map.put(s7, "8");
		map.put(s8, "9");
		map.put(s9, "10");
		
		System.out.println(map);
		System.out.println(map.get(s9));
		
		//Map tr1 = new TreeMap();
		//tr1.put(s, "19");
		
		

	}

}
