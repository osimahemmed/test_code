package com.common;

public class PrimeNumberTest {

	public static void main(String[] args) {
		//int[] arr = new int[1000];
		System.out.println("Prime numbers are " );
		for(int i=4;i<1000;i++) {
			if(isPrime(i)) {
				//arr[i] = i;
				System.out.println(i);
			}
		}

	}
	
	private static boolean isPrime(int num) {
		for(int i=2;i<=num/2;i++) {
			if(num % i == 0) {
				return false;
			}
		}
		return true;
		
	}
	
	private static boolean isPrimeNum(int num) {
		for(int i=2; i <=num/2; i++) {
			if(num % i == 0) {
				return false;
			}
		}
		return true;
		
	}

}
