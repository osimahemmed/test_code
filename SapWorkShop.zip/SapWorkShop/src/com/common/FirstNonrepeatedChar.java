package com.common;

import java.util.LinkedHashMap;
import java.util.Map;

public class FirstNonrepeatedChar {

	public static void main(String[] args) {
		
		//String nonRep = "this is it";//geeksforgeeks
		String nonRep = "geeksforgeeks";
		
		System.out.println("First non repeated char is " + firstNonRepeatedChar(nonRep));

	}
	
	private static Character firstNonRepeatedChar(String input) {
		
		Map<Character, Integer> map = new LinkedHashMap<Character,Integer>();
		
		char ar[] = input.toCharArray();
		char ch;
		
		for(int i = 0; i < ar.length; i++) {
			ch = ar[i];
			if(map.containsKey(ch)) {
				map.put(ch, map.get(ch)+1);
			} else {
				map.put(ch, 1);
			}
		}
		
		
		System.out.println(map);
		for(int i = 0; i < ar.length; i++) {
			ch = ar[i];
			if(map.get(ch) == 1) {
				return ch;
			}
			
		}
		return null;
		
	}

}
