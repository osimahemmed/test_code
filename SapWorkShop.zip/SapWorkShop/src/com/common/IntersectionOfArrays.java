package com.common;

public class IntersectionOfArrays {

	public static void main(String[] args) {
		  int arr1[] = {1, 2, 4, 5, 6};
		  int arr2[] = {2, 3, 5, 7};
		  int sizeArr1 = arr1.length;
		  int sizeArr2 = arr2.length; 
		  printIntersection(arr1, arr2, sizeArr1, sizeArr2);
	}
	
	private static void printIntersection(int[] arr1, int[] arr2, int sizeArr1, int sizeArr2) {
		int i = 0;
		int j = 0;
		while(i < sizeArr1 && j < sizeArr2) {
			if(arr1[i] < arr2[j]) {
				i++;
			} else if(arr2[j] > arr1[i]) {
				j++;
			} else {
				System.out.println(arr2[j++]);
				i++;
			}
		}
		
	}

}
