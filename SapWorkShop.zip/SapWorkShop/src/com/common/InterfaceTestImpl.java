package com.common;

public class InterfaceTestImpl implements InterfaceTest{
	public static void main(String[] args) {
		System.out.println(InterfaceTest.sayHello());
	}
}
