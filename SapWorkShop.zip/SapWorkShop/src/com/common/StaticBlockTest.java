package com.common;

public class StaticBlockTest {

	public static void main(String[] args) {
		
	}

}
