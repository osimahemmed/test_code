package com.common;

public class TestDoWhile {

	public static void main(String[] args) {
		//int i; original question
		int i=0;
		do {
			i++;
		} while(i<0) ;
			
		System.out.println(i);
	}

}
