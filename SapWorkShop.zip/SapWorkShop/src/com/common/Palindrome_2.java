package com.common;

import java.util.Scanner;

public class Palindrome_2 {

	public static void main(String[] args) {
		
		Scanner scanner = new Scanner(System.in);
		System.out.println("Enter the string ");
		
		String s1 = scanner.nextLine();
		scanner.close();
		String s2 = "";
		System.out.println(s1);
		for(int i = s1.length() - 1; i >= 0; i--) {
			s2 = s2+s1.charAt(i);
			System.out.println("output " + s2);
		}
		//System.out.println("output " + s2);
	}

}
