package com.common;

public class FibonacciSeries {

	public static void main(String[] args) {
		
		int prev = -1;
		int res = 1;
		int n = 10;
		for(int i = 0;i < n; i++) {
			int sum = prev+res;
			prev = res;
			res = sum;
			System.out.println(res);
		}
	}

}
