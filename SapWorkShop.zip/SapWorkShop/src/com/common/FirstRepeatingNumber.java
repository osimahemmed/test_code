package com.common;

import java.util.HashSet;
import java.util.Set;

public class FirstRepeatingNumber {

	public static void main(String[] args) {
		int[] A = {5, 5, 3, 2, 1, 2, 2, 3};
		//String str = "abcddesff";
		String str = "geeksforgeeks";
		FirstRepeatingNumber repeat = new FirstRepeatingNumber();
		repeat.firstRepeatingNumber(A);
		//repeat.firstRepeatingChar(str);
		 Character ch = firstRepeatingCh(str);
		 System.out.println("First repeating char : "+ ch);
	}
	
	public void firstRepeatingNumber(int[] A) {
		//int min = -1;
		Set<Integer> set = new HashSet<>();
		for(int i = 0; i < A.length; i++) {
			if(set.contains(A[i])) {
				System.out.println(A[i]);
				break;
			} else {
				set.add(A[i]);
			}
		}
	}	
	
	public void firstRepeatingChar(String str) {
		int min = -1;
		Set<Character> set = new HashSet<>();
		char[] charArr = str.toCharArray();
		for(int i = charArr.length-1; i >= 0; i--) {
			if(set.contains(charArr[i])) {
				min = i;
			} else {
				set.add(charArr[i]);
			}
		}
		if(min != -1) {
			System.out.println("First Repeating Char is "+ charArr[min]);
		} else {
			System.out.println("No repeating Character found");
		}
	}
	
	private static Character firstRepeatingCh(String str) {
		Set<Character> set = new HashSet<>();
		char[] charArr = str.toCharArray();
		for(int i = 0; i < charArr.length; i++) {
			if(set.contains(charArr[i])) {
				return charArr[i];
			} else {
				set.add(charArr[i]);
			}
		}
		
		return '\0';
	}	
}
