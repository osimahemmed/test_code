package com.ds;

class Node {
	
	int value;
	Node left;
	Node right;
	
	public Node(int value) {
		this.value = value;
	}
	
	 Node find(int element) {
		 Node node = null;
		if(this.value == element) {
			return this;
		} 
		
		if(element < this.value && left != null) {
			return left.find(element);
		} else if(right != null) {
			return right.find(element);
		}
		return node;
	}
	
}

public class FindNodeInBinarySearchTree {
	
	
	public static void main(String[] args) {
		Node root = new Node(3);
		root.left = new Node(2);
		root.right = new Node(4);
		root.left.left = new Node(1);
		root.right.right = new Node(5);
		
		System.out.println("Does 3 exist in the tree: " + root.find(3).value);
		System.out.println("Does 7 exist in the tree: " + root.find(5).value);
		System.out.println("Does 7 exist in the tree: " + root.find(45));

	}

}
