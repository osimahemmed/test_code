package com.ds;

public class NthNodeLinkedList {
	
	Node head;
	
	class Node {
		
		int data;
		Node next;
		
		Node(int d) {
			data = d;
			next = null;
		}
	}
	
	private void push(int new_data) {
		/* 1 & 2: Allocate the Node &
        Put in the data*/
		Node new_node = new Node(new_data);
		/* 3. Make next of new Node as head */
		new_node.next = head;
		/* 4. Move the head to point to new Node */
		head = new_node;
	}
	
	void printNthFromLast(int n) {
		Node slow = head;
		Node fast = head;
		
		int count = 0;
		if(head != null) {
			while(count < n) {
				if(fast == null) {
					System.out.println(n + " greater than the number of nodes in the linkedlist ");
					return;
				}
				fast = fast.next;
				count ++;
			}
			while(fast != null) {
				fast = fast.next;
				slow = slow.next;
			}
			System.out.println("Node num  "+n+ " from last is " + slow.data);
		}
		
	}

	public static void main(String[] args) {
		NthNodeLinkedList list = new NthNodeLinkedList();
		list.push(20);
		list.push(4);
		list.push(15);
		list.push(35);
		
		list.printNthFromLast(3);

	}

}
 