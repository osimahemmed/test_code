/*
 * 
 * Algorithm:
Find middle element of linked list using slow and fast pointer method .
Reverse second part of linked list
Compare first and second part of linked list if it matches then linked list is palindrome.
 */

package com.ds;


public class LinkedListPalindromeTest {

	private Node head;

	private class Node {
		private int value;
		private Node next;
		public Node(int value) {
			this.value = value;
			next = null;
		}

	}

	Node curr = null;
	private void push(int new_data) {
		Node new_node = new Node(new_data);
		if(head == null) {
			head = new_node;
			curr = head;
		}
		else {
			curr.next = new_node;
			curr = curr.next;
		}
	}

	/*public void addNode(Node node) {
		if(head == null) {
			head = node;
		} else {
			Node temp = head;
			while(temp.next != null)
				temp = temp.next;
			temp.next = node;
		}
	}*/

	private void printList() {
		Node temp = head;
		while(temp != null) {
			System.out.println(temp.value + " ");
			temp = temp.next;
		}
		System.out.println();
	}

	public static Node middleNode(Node head) {
		Node slow_pointer, fast_pointer;
		slow_pointer = fast_pointer = head;
		while(fast_pointer != null) {
			fast_pointer = fast_pointer.next;
			if(fast_pointer != null && fast_pointer.next != null) {
				fast_pointer = fast_pointer.next;
				slow_pointer = slow_pointer.next;
			}
		}
		return slow_pointer;
	}

	private Node reversLinkedList(Node node) {
		Node prev = null;
		Node next = null;
		Node current = node;

		while(current != null) {
			next = current.next;
			current.next = prev;
			prev = current;
			current = next;
		}
		node = prev;
		return node;
	}

	private boolean checkPalindrome() {
		Node middleNode = middleNode(head);
		Node secondHead = middleNode.next;

	//	middleNode.next = null;
		Node reverseSecondHead = reversLinkedList(secondHead);

		while(head != null && reverseSecondHead != null) {
			if(head.value == reverseSecondHead.value) {
				head = head.next;
				reverseSecondHead = reverseSecondHead.next;

				continue;
			} else {
				return false;
			}
		}
		
		return true;
	}

	public static void main(String[] args) {
		LinkedListPalindromeTest list = new LinkedListPalindromeTest();
		//Node = new Node(1); //12321
		list.push(1);
		list.push(2);
		list.push(3);
		list.push(2);
		list.push(1);
		//list.push(1);

		list.printList();

		boolean b = list.checkPalindrome();
		System.out.println("is Palindrome " +b);
	}
}
