package com.ds;

/*
 * Note that a rectangle can be represented by two coordinates, top left and bottom right. So mainly we are 
 * given following four coordinates.
l1: Top Left coordinate of first rectangle.
r1: Bottom Right coordinate of first rectangle.
l2: Top Left coordinate of second rectangle.
r2: Bottom Right coordinate of second rectangle.
We need to write a function bool doOverlap(l1, r1, l2, r2) that returns true if the two given rectangles overlap.

One solution is to one by one pick all points of one rectangle and see if the point lies 
inside the other rectangle or not. This can be done using the algorithm discussed here.
Following is a simpler approach. Two rectangles do not overlap if one of the following 
conditions is true.
1) One rectangle is above top edge of other rectangle.
2) One rectangle is on left side of left edge of other rectangle.

 */

public class RectangleOverlap {
	
	/*static class Point {
		int x, y;
		public Point(int x, int y) {
			this.x = x;
			this.y = y;
		}
	}*/
	
	static class Point {
		int x, y;
		public Point(int x, int y) {
			this.x = x;
			this.y = y;
		}
		
	}

	public static void main(String[] args) {
		/*Point l1 = new Point (0,10);
		Point r1 = new Point (10,0);
		Point l2 = new Point (5,5);
		Point r2 = new Point (15,0);*/
		Point l1 = new Point(0, 10);
		Point r1 = new Point(10, 0);
		Point l2  = new Point(5,5);
		Point r2 = new Point(15,0);
	    if (doOverlap(l1, r1, l2, r2))
	    	System.out.println("Rectangles Overlapped");
	    else
	    	System.out.println("Rectangles do not Overlap");

	}

	
	static boolean doOverlap(Point l1, Point r1, Point l2, Point r2)
	{
	    // If one rectangle is on left side of other
	    /*if (l1.x > r2.x || l2.x > r1.x)
	        return false;
	 
	    // If one rectangle is above other
	    if (l1.y < r2.y || l2.y < r1.y)
	        return false;*/
		if(l1.x > r2.x || l2.x < r1.x) {
			return false;
		}
		if(l1.y < r2.y || l2.y > r1.y) {
			return false;
		}
	 
	    return true;
	}
}
