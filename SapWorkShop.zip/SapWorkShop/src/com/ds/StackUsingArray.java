package com.ds;

public class StackUsingArray {
	
	int size;
	int arr[];
	int top;
	public StackUsingArray(int size) {
		this.size = size;
		this.arr = new int[size];
		this.top = -1;
	}
	
	public boolean isFull() {
		return (size-1 == top);
	}
	public boolean isEmpty() {
		return (top == -1);
	}
	
	public int peek() {
		return arr[top];
	}
	
	public void push(int data) {
		if(!isFull()) {
			top ++;
			arr[top] = data;
			System.out.println("Pushed element is " + data);
		} else 
		System.out.println("Stack is full");
	}
	public int pop() {
		if(!isEmpty()) {
			int returnPop = top;
			top --;
			System.out.println("Popped element is "+ arr[returnPop]);
			return arr[returnPop];
		} else {
			System.out.println("Stack is empty");
			return -1;
		}
		
	}
	
	public static void main(String[] args) {
		StackUsingArray stack = new StackUsingArray(10);
		stack.pop();
		stack.push(10);
		stack.push(30);
		stack.push(50);
		stack.push(40);
		stack.push(20);
		System.out.println("********************");
		stack.pop();
		stack.pop();
	}
}
