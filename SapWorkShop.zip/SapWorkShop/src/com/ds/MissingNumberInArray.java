package com.ds;

public class MissingNumberInArray {

	public static void main(String[] args) {
		int a[] = {4, 1, 5, 6, 2};
		int len = a.length;
		
	    int miss = getMissingNo(a, len);
	    System.out.println("Missing numeber " + miss);
	    

	}
	
	private static int getMissingNo(int[] a, int n) {
		int i;
	    int x1 = a[0]; /* For xor of all the elements in array */
	    int x2 = 1; /* For xor of all the elements from 1 to n+1 */
	     
	    for (i = 1; i< n; i++) {
	        x1 = x1^a[i];
	    	System.out.println(" x1 =" +x1);
	    }
	            
	    for ( i = 2; i <= n+1; i++) {
	        x2 = x2^i;    
	        System.out.println("x2 " + x2);
	    }
	    
	    return (x1^x2);
	}

}
