package com.ds;

import java.util.Arrays;

public class MaximumDifferenceIntegerArray {

	public static void main(String[] args) {
		
		//int[] arr = {2, 3, 8, 6, 4, 8, 1};
		int[] arr = {7, 9, 5, 6, 13, 2};
		
		/*Arrays.sort(arr);
		
		System.out.println("Max diff " + (arr[arr.length-1]-arr[0]));*/
		int n = arr.length;
		int res = maxDifference(arr, n);
		System.out.println(res);
		
		maxDiff(arr, n);
	}

	//Maximum difference between two elements such that larger
	//element appears after the smaller number
	static int maxDifference(int arr[], int n)
	{
	    int min_element = arr[0];
	    int diff = arr[1] - arr[0];
	    for(int i = 1; i < n; i++)
	    {
	        if(arr[i] - min_element > diff)
	            diff = arr[i] - min_element;
	        if(arr[i] < min_element)
	            min_element = arr[i];
	    }
	    return diff;
	}
	
	private static void maxDiff(int[] arr, int n) {
		
		int max = arr[0];
		int min = arr[0];
		
		for(int num : arr) {
			if(max < num) {
				max = num;
			}
			if(min > num) {
				min = num;
			}
		}
		
		System.out.println("Max difference is :::: " + (max-min));
		
	}

}
