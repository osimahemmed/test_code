package com.ds;

import java.util.HashSet;
import java.util.Set;

public class IntersectionOfArrays {

	public static void main(String[] args) {
		
		 char[] a = {'a', 'b', 'c', 'd'};
	     char[] b = {'c', 'd', 'e', 'f'};
	     System.out.println(intersect(a, b));

	}
	
	private static Set<Character> intersect(char[] a, char[] b) {
		
		Set<Character> aSet = new HashSet<>();
		Set<Character> inters = new HashSet<>();
		for(char c : a) {
			aSet.add(c);
		}
		
		for(char c : b) {
			if(aSet.contains(c)) {
				inters.add(c);
			}
		}
		return inters;
	}
	
}
