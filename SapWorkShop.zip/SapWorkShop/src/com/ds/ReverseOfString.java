package com.ds;

public class ReverseOfString {
	
	String reverse = "";
    
    public String reverseString(String str){
         
        if(str.length() == 1){
            return str;
        } else {
            reverse += str.charAt(str.length()-1)
                    +reverseString(str.substring(0,str.length()-1));
            return reverse;
        }
    }
     
    public static void main(String a[]){
    	ReverseOfString srr = new ReverseOfString();
        System.out.println("Result: "+srr.reverseString("osim ahemmed"));
        System.out.println("reverse is " + srr.reverse("welcome to java"));
    }
    
    private String reverse(String str) {
    	
    	int length = str.length();
    	char[] charArr = str.toCharArray();
    	for(int i = 0; i < length/2; i++) {
    		char ch = str.charAt(i);
    		charArr[i] = charArr[length-1-i];
    		charArr[length-1-i] = ch;
    	}
    	
    	return new String(charArr);
    	
    }
    
    private String revers(String name) {
    	int length = name.length();
    	char[] charArr = name.toCharArray();
    	for(int i = 0; i < length/2; i++) {
    		char ch = name.charAt(i);
    		charArr[i] = charArr[length-1-i];
    		charArr[length-1-i] = ch;
    	}
    	return new String(charArr);
    }

}
