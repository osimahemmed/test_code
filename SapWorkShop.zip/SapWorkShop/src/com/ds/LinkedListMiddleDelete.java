package com.ds;

public class LinkedListMiddleDelete {
	
	Node head;
	
	class Node {
		int data;
		Node next;
		Node(int d) {
			data = d;
			next = null;
		}
	}
	
	
	Node curr = null;
	private void push(int new_data) {
		
		Node new_node = new Node(new_data);
		if(head == null) {
			head = new_node;
			curr = head;
		} else {
			curr.next = new_node;
			curr = curr.next;
					
		}
	}
	
	public Node printMiddle() {
		Node fast_ptr = head;
		Node slow_ptr = head;
		if(head != null) {
			while(fast_ptr != null && fast_ptr.next != null) {
				fast_ptr = fast_ptr.next.next;
				slow_ptr = slow_ptr.next;
			}
			System.out.println("The middle element is [" +slow_ptr.data+ "] \n");
			//return slow_ptr;
		}
		
		return slow_ptr;
	}
	
	void printList() {
		Node tNode = head;
		while(tNode != null) {
			System.out.println(tNode.data);
			tNode = tNode.next;
		}
	}
	
	private boolean deleteMiddleNode(Node middle) {
		
		if(middle == null || middle.next == null) {
			return false;
		}
		
		Node temp = middle.next;
		middle.data = temp.data;
		middle.next = temp.next;
		
		return true;
	}

	public static void main(String[] args) {
		
		LinkedListMiddleDelete list = new LinkedListMiddleDelete();
		
		
			list.push(5);
			list.push(4);
			list.push(3);
			list.push(2);
			list.push(1);
			
			list.printList();
			//list.printList();
			
			Node node = list.printMiddle();
		
		//list.deleteMiddleNode();
		boolean b = list.deleteMiddleNode(node);
		System.out.println(b);
		list.printList();

	}

}
