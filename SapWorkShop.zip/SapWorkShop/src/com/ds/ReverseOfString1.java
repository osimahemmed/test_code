package com.ds;

public class ReverseOfString1 {

	public static void main(String[] args) {
		String s = "hello welcome to sapient";
		System.out.println(reverse(s));

	}
	
	private static String reverse(String s) {
		String[] split = s.split(" ");
		String result = "";
		for(int i=split.length-1; i>=0; i--) {
			result += split[i] + " "; 
		}
		return result;
	}
}
