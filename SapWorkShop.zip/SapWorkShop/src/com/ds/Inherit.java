package com.ds;

public class Inherit extends SubclassNotInherit {
	
	public static void main(String[] args) {
		System.out.println("hello");
		SubclassNotInherit a = new Inherit();
		//a.test();
		//System.out.println(a.val);
	}

}
