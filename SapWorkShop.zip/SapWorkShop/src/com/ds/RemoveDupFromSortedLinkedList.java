package com.ds;

public class RemoveDupFromSortedLinkedList {

	Node head;

	class Node {
		int data;
		Node next;
		Node(int d) {
			data = d;
			next = null;
		}
	}

	private void push(int new_data) {
		Node new_node = new Node(new_data);
		new_node.next = head;
		head = new_node;
	}

	private void printList() {
		Node temp = head;
		while(temp != null) {
			System.out.println(temp.data+ " ");
			temp = temp.next;
		}
		System.out.println();
	}

	private void removeDuplicatesFromSortedList() {

		Node current = head;
		Node next_next;

		if(head == null)
			return;

		while(current.next != null) {
			
			if(current.data == current.next.data) {
				next_next = current.next.next;
				current.next = null;
				current.next = next_next;
				System.out.println();
			} else {
				current = current.next;
			}
		}
	}

	private void deleteDupsUnSorted() {

		Node current = head;
		if(head == null)
			return;
			while(current != null) {
			Node temp = current;
			while(temp.next != null) {
				if(temp.next.data == current.data)
					temp.next = temp.next.next;
				else 
					temp = temp.next;
			}
			current = current.next;
		}
	}

	public static void main(String[] args) {
		RemoveDupFromSortedLinkedList llist = new RemoveDupFromSortedLinkedList();
		/*llist.push(20);
        llist.push(13);
        llist.push(13);
        llist.push(11);
        llist.push(11);
        llist.push(11);*/

		llist.push(13);
		llist.push(13);
		llist.push(20);
		llist.push(11);
		llist.push(9);
		llist.push(11);

		System.out.println("List before removal of duplicates");
		llist.printList();

		//llist.removeDuplicatesFromSortedList();
		llist.deleteDupsUnSorted();

		System.out.println("List after removal of elements");
		llist.printList();

	}

}
