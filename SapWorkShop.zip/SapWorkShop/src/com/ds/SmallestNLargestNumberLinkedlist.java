package com.ds;

public class SmallestNLargestNumberLinkedlist {
	
	Node head;
	class Node {
		int data;
		Node next;
		
		Node(int d) {
			this.data = d;
			next = null;
		}
	}
	
	private void push(int data) {
		Node new_node = new Node(data);
		new_node.next = head;
		head = new_node;
	}
	
	static int smallestInt(Node head) {
		int min = Integer.MAX_VALUE;
		while(head != null) {//5,1,6,2,3
			if(min > head.data) {
				min = head.data;
			}
			head = head.next;
		}
		
		return min;
		/*int min = Integer.MAX_VALUE;
		while(head != null) {
			if(min > head.data) {
				min = head.data;
			}
			head = head.next;
		}
		
		return min;*/
	}
	
	static int largestNum(Node head) {
		int max = Integer.MIN_VALUE;
		while(head != null) {//1,0,40,34,90
			if(max < head.data) {
				max = head.data;
			}
			head = head.next;
		}
		return max;
	}

	public static void main(String[] args) {
		SmallestNLargestNumberLinkedlist st = new SmallestNLargestNumberLinkedlist();
		st.push(34);
		st.push(12);
		st.push(4);
		st.push(67);
		st.push(22);
		st.push(53);
		st.push(-1);

		int small = smallestInt(st.head);
		System.out.println("Smallest Number " +small);
		int larg = largestNum(st.head);
		System.out.println("Largest Number " + larg);
	}

}
