package com.ds;

public class LCAOfBinarySearchTree {
	
	static class Node {
		
		int data;
		Node left, right;
		public Node(int data) {
			this.data = data;
			left = right = null;
		}
	}
	
	Node root;
	
	Node lca(Node root,Node n1, Node n2) {
		
		if(root == null)
			return null;
		if(root.data > n1.data && root.data > n2.data) {
			return lca(root.left, n1, n2);
		}
		if(root.data < n1.data && root.data < n2.data) {
			return lca(root.right, n1, n2);
		}
		return root;
	}

	public static void main(String[] args) {
		
		LCAOfBinarySearchTree lca_bst = new LCAOfBinarySearchTree();
        lca_bst.root = new Node(20);
        lca_bst.root.left = new Node(8);
        lca_bst.root.right = new Node(22);
        lca_bst.root.left.left = new Node(4);
        lca_bst.root.left.right = new Node(12);
        lca_bst.root.left.left.left = new Node(10);
        lca_bst.root.left.right.right = new Node(14);
 
        Node n1 =new Node(10);
        Node n2 =new Node(14);
        //, n2 = 14;
        Node t = lca_bst.lca(lca_bst.root, n1, n2);
        System.out.println("LCA of n1 and n2 is : " +t.data);
        //lca_bst.printLevelOrder();

	}

}
