/*
let�s say Array is {1,2,3,4,5,6,7,8}
You want to rotate by k position.
It will work as below:
You rotate the whole array. So array became: {8,7,6,5,4,3,2,1}
Reverse first k elements, so array became : {7,8,6,5,4,3,2,1}
Reverse rest of elements, so array became  : {7,8,1,2,3,4,5,6}
 */

package com.ds;

public class RotateAnArrayKthTimes {

	public static void main(String[] args) {
		
		int[] nums3 = {1, 2, 3, 4, 5, 6, 7, 8, 9,10};
		int[] result3 = rotateOptimized(nums3, 15);
		printArray(result3);

	}
	
	
	public static int[] rotateOptimized(int[] nums,int k)
	{
		int n = nums.length;
		if(k > n) 
	        k = k % n;
		nums = reverse(nums, 0, n-1);
		nums = reverse(nums, 0, k-1);
		nums = reverse(nums, k, n-1);
		return nums;
	}
	public static int[] reverse(int[] nums, int start, int end)
	{
	
		while (start <= end ) {
			int temp = nums[start];
			nums[start] = nums[end];
			nums[end] = temp;
			start++;
			end--;
		}
		return nums;
	}
	
	public static void printArray(int []arr)
	{
		for (int i = 0; i < arr.length; i++) {
			System.out.print(arr[i]+" ");
		}
	}

}
