package com.ds;

import java.util.LinkedList;
import java.util.Queue;
import java.util.Stack;

public class BSTToLargerSumTree {
	
	Node root;
	static class Node {
		int data;
		Node left, right;
		
		public Node(int data) {
			this.data = data;
			left = right = null;
		}
	}
	int sum = 0;
	private Node convertBST(Node root) {
		if(root != null) {
			convertBST(root.right);
			sum = sum + root.data;
			root.data = sum;
			convertBST(root.left);
		}
		//printLevelOrder(root);
		return root;
	}
	
	private Node convertBSTMaxSum(Node root) {
		int sum = 0;
		Node node = root;		
		Stack<Node> stack = new Stack<Node>();
		while(!stack.isEmpty() || node != null) {
			
			 /* push all nodes up to (and including) this subtree's maximum on
             * the stack. */
			while(node != null) {
				stack.add(node);
				node = node.right;
			}
			
			node = stack.pop();
			sum = sum+node.data;

			node.data = sum;
			
			/* all nodes with values between the current and its parent lie in
             * the left subtree. */
			node = node.left;
			
			
		}
		return root;
	}
	
	private static void printLevelOrder(Node root) {
		Queue<Node> q = new LinkedList<Node>();
		q.add(root);
		while(!q.isEmpty()) {
			Node temp = q.poll();
			System.out.println(temp.data + " ");
			//System.out.println();
			if(temp.left != null) {
				q.add(temp.left);
			}
			if(temp.right != null) {
				q.add(temp.right);
			}
		}
	}
	
	public static void main(String[] args) {
		BSTToLargerSumTree tree = new BSTToLargerSumTree();
		tree.root = new Node(20);
		tree.root.left = new Node(8);
		tree.root.right = new Node(22);
		tree.root.left.left = new Node(4);
		tree.root.left.right = new Node(12);
		tree.root.left.right.left = new Node(10);
		tree.root.left.right.right = new Node(14);

		printLevelOrder(tree.root);
		tree.convertBST(tree.root);
		//tree.convertBSTMaxSum(tree.root);
		System.out.println("After BST");
		printLevelOrder(tree.root);
		
	}

}
