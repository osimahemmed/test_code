package com.ds;

public class LinkedListDeletionGreaterThanGivenNum {
	
	Node head;
	
	class Node {
		int data;
		Node next;
		Node(int d) {
			data = d;
			next = null;
		}
	}

	/*void printMiddle() {
		Node slow_ptr = head;
		Node fast_ptr= head;
		 if(head !=null) {
			 while(fast_ptr != null && fast_ptr.next != null) {
				 fast_ptr = fast_ptr.next.next;
				 slow_ptr = slow_ptr.next;
			 }
			 System.out.println("Middle element is " + slow_ptr.data);
		 }
		
	}*/
	
	public void push(int new_data) {
		Node new_node = new Node(new_data);
		new_node.next = head;
		head = new_node;
	}
	
	private Node removeNodes() {

		Node start = head;
		int x = 5;
		if(start == null) return start;

		if(start.data > x && start.next == null) 
			return null;

		//find first head node
		Node cur = start;
		Node prev = null;

		//4,5,3,2,1,6 --- where x = 2
		while(cur != null && cur.data > x) {
		    prev = cur;
		    cur = cur.next;
		}

		if(prev != null) 
			prev.next = null;

		Node newHead = cur;

		while(cur.next != null) {
		    if(cur.next.data > x) {
		        cur.next = cur.next.next;
		    } else {
		        cur = cur.next;
		    }
		}

		return newHead;
		}

	
	public void printList() {
		Node tNode = head;
		while(tNode != null) {
			System.out.println(tNode.data + "-->");
			tNode = tNode.next;
		}
		//System.out.println("Null");
	}
	
	public static void main(String[] args) {
		LinkedListDeletionGreaterThanGivenNum list = new LinkedListDeletionGreaterThanGivenNum();
		for(int i = 10; i > 0; --i) {
			list.push(i);
			
			//list.printMiddle();
		}
		list.removeNodes();
		list.printList();

	}
}
