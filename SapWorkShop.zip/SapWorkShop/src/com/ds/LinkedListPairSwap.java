package com.ds;

public class LinkedListPairSwap {
	
	Node head;
	
	 class Node {
		 int data;
		 Node next;
		 Node(int d) {
			 data = d;
			 next = null;
		 }
	 }
	 
	 void pairWiseSwap() {
		 Node temp = head;
		 
		 while(temp != null && temp.next != null) {
			 int k = temp.data;
			 temp.data = temp.next.data;
			 temp.next.data = k;
			 temp = temp.next.next;
		 }
	 }
	 
	 void pairSWap() {
		 
		 Node temp = head;
		 while(temp != null && temp.next != null) {
			 int k = temp.data;
			 temp.data = temp.next.data;
			 temp.next.data = k;
			 temp = temp.next.next;
		 }
		 
		 /*Node temp = head;
		 while(temp != null && temp.next != null) {
			 int k = temp.data;
			 temp.data = temp.next.data;
			 temp.next.data = k;
			 temp = temp.next.next;
		 }*/
	 }
	 
	 Node curr = null;
	 public void push(int new_data) {
		 Node new_node = new Node(new_data);
		 if(head == null) {
			 head = new_node;
			 curr = head;
		 } else {
			 curr.next = new_node;
			 curr = curr.next;
		 }
		
	 }
	 
	 void printList() {
		 Node temp  = head;
		 while(temp != null) {
			 System.out.println(temp.data + " ");
			 temp = temp.next;
		 }
		 System.out.println();
	 }

	public static void main(String[] args) {
			LinkedListPairSwap llist = new LinkedListPairSwap();
			llist.push(1);
			llist.push(2);
			llist.push(3);
			llist.push(4);
			llist.push(5);
	         
	        System.out.println("Linked List before calling pairWiseSwap() ");
	        llist.printList();
	         
	        llist.pairWiseSwap();
	         
	        System.out.println("Linked List after calling pairWiseSwap() ");
	        llist.printList();
	}

}
