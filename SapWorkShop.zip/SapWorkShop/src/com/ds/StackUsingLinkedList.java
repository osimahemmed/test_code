package com.ds;

public class StackUsingLinkedList {
	
	private Node head;
	
	private class Node {
		int value;
		Node next;
	}
	public StackUsingLinkedList() {
		head = null;
		
	}
	public void push(int value) {
		Node oldHead = head;
		head = new Node();
		head.value = value;
		head.next = oldHead;
	}

	public int pop() throws LinkedListEmptyException {
		if(head == null) {
			throw new LinkedListEmptyException();
		} 
		int value = head.value;
		head = head.next;
		return value;
	}
	public static void printList(Node head) {
		Node temp = head;
		while(temp != null) {
			System.out.println(temp.value);
			temp = temp.next;
		}
		System.out.println();
	}
	public static void main(String [] args) {
		StackUsingLinkedList stack = new StackUsingLinkedList();
			stack.push(20);
			stack.push(50);
			stack.push(80);
			stack.push(90);
			stack.push(60);
			stack.push(75);
			
			System.out.println("Element removed from LinkedList: "+stack.pop());  
	        System.out.println("Element removed from LinkedList: "+stack.pop());  
	        stack.push(10);  
	        System.out.println("Element removed from LinkedList: "+stack.pop());  
	        printList(stack.head);

	}
}
