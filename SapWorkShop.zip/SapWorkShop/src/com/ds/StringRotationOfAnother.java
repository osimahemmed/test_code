package com.ds;

public class StringRotationOfAnother {

	public static void main(String[] args) {

		String orig = "IndiaVsEngland";
		String rot = "EnglandIndiaVs";
		String s1 = "IndiaVsAustralia";
		String rotation = "AustraliaIndiaVs";
		boolean b = checkRotation(orig, rot);
		System.out.println(b);
	}
	
	private static boolean checkRotation(String original, String rotation) {
		if(original.length() != rotation.length()) {
			return false;
		}
		String concated = original+original;
		if(concated.indexOf(rotation) != -1) {
			return true;
		}
		return false;
	}

}
