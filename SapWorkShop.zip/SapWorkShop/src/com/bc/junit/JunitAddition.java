package com.bc.junit;

import static org.junit.Assert.*;

import org.junit.Test;
import org.mockito.Mockito;

public class JunitAddition {
	private Addition mock;
	
	@Test
	public void testAdd() {
		mock = Mockito.mock(Addition.class);
		try {
			mock.add(2, 3);
		} catch (Exception e) {
			// TODO: handle exception
		}
		
		//assertEquals(Addition.add(2, 3),5);
	}

}
