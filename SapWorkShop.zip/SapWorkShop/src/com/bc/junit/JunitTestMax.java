package com.bc.junit;

import static org.junit.Assert.*;

import org.junit.Test;

public class JunitTestMax {
	
	@Test
	public void testMax() {
		assertEquals(100,FindMax.findMax(new int[]{1,3,4,2,100,0}));
		assertEquals(-1, FindMax.findMax(new int[]{-12,-1,-3,-4,-2}));
	}

}
