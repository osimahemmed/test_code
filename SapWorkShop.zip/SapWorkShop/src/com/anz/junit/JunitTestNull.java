package com.anz.junit;

import static org.junit.Assert.*;

import org.junit.Test;

public class JunitTestNull {
	
	@Test
	private void nullTest() {
		assertNull(new NullTest().testNull());
	}

}
