package com.anz.test;

public class MyExc1 extends Exception {

}
