package com.anz.test;

public class MyExc2 extends Exception {

}
