package com.anz.test;

public class MyExc3 extends MyExc2 {

}
