package com.abc.test;

public class MyExc2 extends Exception {

}
