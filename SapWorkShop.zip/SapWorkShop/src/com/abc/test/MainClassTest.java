package com.abc.test;

public class MainClassTest {

	public static void main(String[] a) {
		System.out.println("hello");

	}

}
