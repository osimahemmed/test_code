package com.abc.test;

public class MyClass {
	
	public int multiply(int a, int b) {
		int c = a*b;
		//System.out.println(c);
		return c;
	}

}
